# MoneyXp 1.9.4

Standalone MelonLoader / BTD6 Mod Helper mod for **single-player** money, level, knowledge,
powers, heroes, skins and upgrade unlocks. It does not touch BloonPoker.

## Install

Requires MelonLoader 0.6.x/0.7.x (IL2CPP) and BTD6 Mod Helper.

1. Close BTD6 completely.
2. Copy `MoneyXp.dll` into your Mods folder. Keep the exact filename.
   - Android: `/storage/emulated/0/Android/data/com.ninjakiwi.bloonstd6/files/Mods/`
   - Netflix build: `com.netflix.NGP.BloonsTDSix` instead of `com.ninjakiwi.bloonstd6`.
   - PC: `BloonsTD6/Mods/`
3. Launch the game. The Mod Helper mod list shows **Monkey Money & Unlocks**; use its gear
   button for the settings.

## Settings

- Monkey money, player level, knowledge books and power count apply when you change them.
- **Unlock heroes & skins** and **Unlock all knowledge** are toggles.
- **Unlock all knowledge** off clears every knowledge node; on fills every node.
- Upgrade tiers are unlocked once on load. A `MoneyXp.upgrades` marker is written next to the
  dll; later launches skip the scan. Delete that marker to force one more scan.
- There is no timer and no background money/knowledge top-up. Money and knowledge are applied
  on load and when you change a setting.

## Important

- Single-player only. Using mods in co-op, races, contested territories or boss events can
  flag your Ninja Kiwi account. Do not use this on an account you want to keep clean.
- This edits the local profile and asks the game to save it. Back up your save first.
- Not affiliated with Ninja Kiwi.

## Release file

`MoneyXp.dll` &middot; 38400 bytes &middot; SHA-256 `1c2c257a982a307668f49a2d4c00b55f95aa612d6521a9d47d66f9217224289c`

Built from the 1.9.4 source with 0 warnings and 0 errors.
